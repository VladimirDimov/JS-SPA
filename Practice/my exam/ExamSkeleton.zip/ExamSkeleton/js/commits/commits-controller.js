(function () {
    'use strict'

    function ProjectsCtrl($scope, commitsSrv, notifier, $location) {
        $scope.commits = {};
        $scope.getCommits = function getCommits() {
            commitsSrv.getCommits()
                .then(function (res) {
                    $scope.commits = res;
                });
        }
    };

    angular.module('app.controllers')
        .controller('CommitsCtrl', ['$scope', 'commitsSrv', 'notifier', '$location', ProjectsCtrl]);
} ());