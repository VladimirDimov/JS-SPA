(function () {
    'use strict'


    function CommitDetailsCtrl($scope, commitsSrv, notifier, $routeParams) {
        $scope.commit = {};
        
        $scope.getCommitDetails = function getCommitDetails() {
            commitsSrv.getById($routeParams.id)
                .then(function (res) {
                    $scope.commit = res;
                });
        }
    };

    angular.module('app.controllers')
        .controller('CommitDetailsCtrl', ['$scope', 'commitsSrv', 'notifier', '$routeParams', CommitDetailsCtrl]);
} ());