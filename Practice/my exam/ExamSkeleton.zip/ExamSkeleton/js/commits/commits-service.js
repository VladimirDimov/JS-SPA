(function () {
    'use strict';

    function commitsSrv(dataSrv) {
        return {
            getCommits: function getCommits() {
                return dataSrv.get('api/commits')
            },
            getById: function (id) {
                return dataSrv.get('api/commits/' + id);
            },
            getByProject: function (id) {
                return dataSrv.get('api/commits/byproject/' + id);
            }
        };
    };

    angular.module('app.services')
        .factory('commitsSrv', ['dataSrv', commitsSrv])
} ());