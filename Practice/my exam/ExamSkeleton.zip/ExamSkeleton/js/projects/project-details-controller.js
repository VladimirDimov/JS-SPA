(function () {
    'use strict';

    function ProjectDetailsCtrl($scope, $location, projectsSrv, commitsSrv, authSrv, $routeParams, notifier) {
        checkAuth();
        $scope.project = {};
        $scope.newCommit = {};

        function checkAuth() {
            if (!authSrv.isLogged()) {
                $location.path('/unauthorized');
            }
        };

        $scope.getProjectDetails = function getProjectDetails() {
            projectsSrv.getById($routeParams.id)
                .then(function (res) {
                    $scope.project = res;
                });
        }

        $scope.addCommit = function addCommit(newCommit) {
            newCommit.projectId = $scope.project.Id || $routeParams.id;
            projectsSrv.addCommit(newCommit)
                .then(function (res) {
                    notifier.success("New commit added!");
                    $location.path("projects/" + $routeParams.id);
                }, function (err) {
                    notifier.error(err);
                });
        };

        $scope.getProjectCommits = function () {
            $scope.commits = commitsSrv.getByProject($routeParams.id)
                .then(function (res) {
                    $scope.commits = res;
                });
        };

        $scope.getCollaborators = function getCollaborators() {
            $scope.collaborators = projectsSrv.getCollaborators($routeParams.id)
                .then(function (res) {
                    $scope.collaborators = res;
                });
        };

        $scope.addCollaborator = function addCollaborator() {
            projectsSrv.addCollaborator($scope.collaboratorUsername, $routeParams.id)
                .then(function () {
                    notifier.siccess("Collaborator added!");
                }, function (err) {
                    notifier.error(err);
                });
        };
    };

    angular.module('app.controllers')
        .controller('ProjectDetailsCtrl', ['$scope', '$location', 'projectsSrv', 'commitsSrv', 'authSrv', '$routeParams', 'notifier', ProjectDetailsCtrl]);
} ());