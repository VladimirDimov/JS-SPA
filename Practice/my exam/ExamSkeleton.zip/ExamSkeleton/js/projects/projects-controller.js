(function () {
    'use strict'

    function ProjectsCtrl($scope, projectsSrv, notifier, $location) {
        $scope.projects;
        $scope.request = {
            page: 1,
            pageSize: 10
        };

        $scope.getProjects = function getProjects() {
            var request = $scope.request;
            var strings = [];
            var keys = Object.keys(request);
            for (var i = 0; i < keys.length; i++) {
                if (request[keys[i]]) {
                    strings.push(keys[i] + '=' + request[keys[i]]);
                }
            }

            projectsSrv.getProjectsAuthorized(strings.join('&'))
                .then(function (res) {
                    $scope.projects = res;
                }, function (err) {
                    notifier.error(err);
                });
        };
    };

    angular.module('app.controllers')
        .controller('ProjectsCtrl', ['$scope', 'projectsSrv', 'notifier', '$location', ProjectsCtrl]);
} ());