(function () {
    'use strict';

    function CreateProjectCtrl($scope, projectsSrv, notifier, $location, authSrv) {

        checkAuth();

        function checkAuth() {
            if (!authSrv.isLogged()) {
                $location.path('/unauthorized');
            }
        };

        $scope.create = function create(project) {
            projectsSrv.create(project)
                .then(function (res) {
                    notifier.success('Project with id ' + res + ' added successfully!');
                    $location.path('/projects');
                }, function (err) {
                    notifier.error(err);
                });
        };
    };

    angular.module('app.controllers')
        .controller('CreateProjectCtrl', ['$scope', 'projectsSrv', 'notifier', '$location', 'authSrv', CreateProjectCtrl]);
} ());