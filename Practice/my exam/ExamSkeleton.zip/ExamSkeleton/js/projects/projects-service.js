(function () {
    'use strict';

    function projectsSrv(dataSrv) {
        return {
            create: function create(project) {
                return dataSrv.post("api/projects", project);
            },
            getProjects: function getProjects() {
                return dataSrv.get('api/projects')
            },
            getProjectsAuthorized: function getProjects(queryString) {
                return dataSrv.get('api/projects/all?' + queryString);
            },
            getById: function (id) {
                return dataSrv.get('api/projects/' + id);
            },
            addCommit: function (commit) {
                return dataSrv.post('api/commits', commit);
            },
            getCollaborators: function (id) {
                return dataSrv.get('api/projects/collaborators/' + id);
            },
            addCollaborator: function (collaborator, projectId) {
                return dataSrv.put('api/projects/' + projectId, { "collaborator": collaborator });
            }
        };
    };

    angular.module('app.services')
        .factory('projectsSrv', ['dataSrv', projectsSrv])
} ());