(function () {
    function config($routeProvider, $location) {
        $routeProvider
            .when('/', {
                controller: function ($location) {
                    $location.path('/home');
                },
                template: ''
            })
            .when('/home', {
                templateUrl: '/html/home/home.html',
                controller: 'HomeCtrl'
            })
            .when('/register', {
                templateUrl: '/html/auth/register.html',
                controller: 'RegisterCtrl'
            })
            .when('/login', {
                templateUrl: 'html/auth/login.html',
                controller: 'LoginCtrl'
            })
            .when('/logout', {
                controller: function () {
                    $location.path('/home');
                }
            })
            .when('/projects', {
                templateUrl: '/html/projects/projects.html',
                controller: 'ProjectsCtrl'
            })
            .when('/projects/add', {
                templateUrl: '/html/projects/create-project.html',
                controller: 'CreateProjectCtrl'
            })
            .when('/projects/:id', {
                templateUrl: '/html/projects/project-details.html',
                controller: 'ProjectDetailsCtrl'
            })
            .when('/projects/:id/addcommits', {
                templateUrl: '/html/commits/add-commit.html',
                controller: 'ProjectDetailsCtrl'
            })
            .when('/commits', {
                templateUrl: '/html/commits/commits.html',
                controller: 'CommitsCtrl'
            })
            .when('/commits/:id', {
                templateUrl: '/html/commits/commit-details.html',
                controller: 'CommitDetailsCtrl'
            })
            .when('/unauthorized', {
                templateUrl: '/html/unauthorized/unauthorized.html'
            })
            .otherwise({
                controller: function ($location) {
                    $location.path('/unauthorized');
                },
                template: ''
            });
    };

    angular.module('app.services', ['angular-md5']);
    angular.module('app.controllers', ['app.services']);
    angular.module('app.directives', []);
    angular.module('app.filters', []);
    angular.module('app', ['ngRoute', 'toastr', 'app.controllers', 'app.directives', 'app.filters', 'kendo.directives'])
        .config(['$routeProvider', config])
        .constant('globalConstants', {
            baseAddress: 'http://localhost:42252/'
        });
} ());