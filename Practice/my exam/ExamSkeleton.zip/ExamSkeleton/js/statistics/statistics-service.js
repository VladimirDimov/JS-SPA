(function () {
    'use strict';

    function statisticsSrv(dataSrv, $q) {
        var statistics;

        return {
            getStatistics: function () {
                if (statistics) {
                    return $q.when(statistics);
                } else {
                    return dataSrv.get('api/statistics')
                        .then(function (res) {
                            statistics = res;
                            return statistics;
                        });
                }
            }
        }
    };

    angular.module('app.services')
        .factory('statisticsSrv', ['dataSrv', '$q', statisticsSrv])
} ());