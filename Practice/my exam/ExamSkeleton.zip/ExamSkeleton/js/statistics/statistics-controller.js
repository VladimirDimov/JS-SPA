(function () {
    'use strict';

    function StatisticsCtrl($scope, statisticsSrv) {
        $scope.statistics;
        statisticsSrv.getStatistics()
            .then(function (res) {
                $scope.statistics = res;
            });
    };

    angular.module('app.controllers')
        .controller('StatisticsCtrl', ['$scope', 'statisticsSrv', StatisticsCtrl])
} ());