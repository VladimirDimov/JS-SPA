(function () {
    'use strict'

    function authSrv($http, $q, globalConstants, md5) {
        function login(user) {
            var defered = $q.defer();
            var data = "grant_type=password&username=" + user.username + "&password=" + md5.createHash(user.password || '');
            var address = globalConstants.baseAddress + 'token';

            $http.post(address, data, {
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
            }).success(function (data) {
                defered.resolve(data);
            }).error(function (err) {
                defered.reject(err);
            });

            return defered.promise;
        };

        function register(user) {
            var defered = $q.defer();
            var address = globalConstants.baseAddress + 'api/account/register';

            var data = {
                Email: user.email,
                Password: md5.createHash(user.password || ''),
                ConfirmPassword: md5.createHash(user.confirmPassword || '')
            };

            $http.post(address, data, {
                headers: {
                    'Content-Type': 'application/json'
                }
            }).success(function (res) {
                defered.resolve(res);
            }).error(function (err) {
                defered.reject(err);
            });

            return defered.promise;
        };

        function updateUserOnLocalStorage(data) {
            localStorage.setItem('userInfo', JSON.stringify(data));
        };

        function logout() {
            var defered = $q.defer();
            var address = globalConstants.baseAddress + 'api/account/logout';
            var headers = getAuthorizationHeaders();

            $http.post(address, null, headers)
                .success(function (res) {
                    defered.resolve(res);
                }).error(function (err) {
                    defered.reject(err);
                });

            localStorage.clear();
            return defered.promise;
        };

        function getCurrentUserInfo() {
            var userInfo = JSON.parse(localStorage.getItem('userInfo'));
            return userInfo;
        }

        function getAuthorizationHeaders() {
            var userInfo = getCurrentUserInfo();
            if (!userInfo) {
                return {};
            } else {
                return {
                    headers: {
                        "Authorization": 'Bearer ' + (userInfo.access_token || '')
                    }
                }
            }
        }

        function isLogged() {
            if (localStorage.userInfo) {
                return true;
            }

            return false;
        }

        return {
            login: login,
            register: register,
            updateUserOnLocalStorage: updateUserOnLocalStorage,
            logout: logout,
            getCurrentUserInfo: getCurrentUserInfo,
            getAuthorizationHeaders: getAuthorizationHeaders,
            isLogged: isLogged
        }
    };

    angular.module('app.services')
        .factory('authSrv', ['$http', '$q', 'globalConstants', 'md5', authSrv]);
} ());