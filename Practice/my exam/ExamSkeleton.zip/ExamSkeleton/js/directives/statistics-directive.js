(function () {
    'use strict';

    function mdStatistics() {
        return {
            restrict: 'A',
            replace: false,
            templateUrl: '/html/home/statistics.html',
            controller: 'StatisticsCtrl'
        };
    };

    angular.module('app.directives')
        .directive('mdStatistics', [mdStatistics]);
} ());