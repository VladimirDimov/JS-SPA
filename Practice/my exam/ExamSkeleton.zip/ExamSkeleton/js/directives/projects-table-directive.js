(function () {
    'use strict';

    function mdProjectsTable() {
        return {
            restrict: 'A',
            replace: false,
            scope: true,
            templateUrl: '/html/projects/projects-table.html',
            controller: function ($scope, projectsSrv) {
                projectsSrv.getProjects()
                    .then(function (res) {
                        $scope.projects = res;
                    });
            }
        };
    };

    angular.module('app.directives')
        .directive('mdProjectsTable', ['projectsSrv', mdProjectsTable]);
} ());